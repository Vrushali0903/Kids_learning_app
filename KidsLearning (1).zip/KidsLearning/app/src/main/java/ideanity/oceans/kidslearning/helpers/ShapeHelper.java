package ideanity.oceans.kidslearning.helpers;

public class ShapeHelper {

    int image;

    public ShapeHelper(int image) {
        this.image = image;
    }


    public int getImage() {
        return image;
    }
}


