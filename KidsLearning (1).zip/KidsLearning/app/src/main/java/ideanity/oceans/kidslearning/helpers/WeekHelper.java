package ideanity.oceans.kidslearning.helpers;

public class WeekHelper {

    String title;

    public WeekHelper(String title) {
        this.title = title;
    }


    public String getTitle() {
        return title;
    }
}


