package ideanity.oceans.kidslearning.helpers;

public class AlphabetHelper {

    String title;

    public AlphabetHelper(String title) {
        this.title = title;
    }


    public String getTitle() {
        return title;
    }
}


