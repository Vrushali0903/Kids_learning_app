package ideanity.oceans.kidslearning.helpers;

import android.graphics.drawable.Drawable;

public class NumberHelper {

    String title;

    public NumberHelper(String title) {
        this.title = title;
    }


    public String getTitle() {
        return title;
    }
}


